# Home - v2.2.4-test

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/ig/ImplementationGuide/hl7.fhir.no.basis | *Version*:2.2.4-test |
| Draft as of 2026-10-04 | *Computable Name*:NoBasis |

### This is a test of a new build pipeline for no-basis

This repo is currently a test for running a new build pipeline for HL7 Norway's no-basis profiles.

### About no-basis

The Norwegian basisprofiles are developed by HL7 Norway and The Norwegian Directorate of eHealth in cooperation with the industry. The profiles are use-case independent and have several purposes:

* Can be used directly in use cases where the use-case don't need additional information or restrictions
* Can be used as a basis for further profiling in use-cases where additional specification of the content is needed (national profiles). In this case the basis profiles should be used as a base for national profiles developed by the user
* Can be used as inspiration for use-case specific profiling

The basis profiles are open, in effect it does not add any restrictions to the information content beyond what is necessary to apply FHIR resources in Norwegian context. The basis profiles typically profiles necessary identifiers and coding used in Norway.

The model under visualizes the role of Norwegian base profiles. On top are the FHIR resources as defined by HL7 International. The Norwegian base profiles describes the minimum restrictions necessary independent of use-case to use a given FHIR resource in Norway.
 The national profiles specifies further any reuseable patterns within a given use-case. This can for example be what information elements in Patient should be supported when exchanging patient data, or how Medication.dosage should be descried in an integration between an EHR and a charting system. The level of implemented profiles represents the actual interface implemented in a given clinial application.

 ![](https://raw.githubusercontent.com/HL7Norway/basisprofiler-r4/master/Images/profilering-hierarki.PNG)

