# Patient Example - v2.2.3-test

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient Example**

## Example Patient: Patient Example

Peter James Chalmers (official) (no stated gender), DoB Unknown

-------



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "PatientExample",
  "name" : [
    {
      "use" : "official",
      "family" : "Chalmers",
      "given" : ["Peter James"]
    }
  ]
}

```
